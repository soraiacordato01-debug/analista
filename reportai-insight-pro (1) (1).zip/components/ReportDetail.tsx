
import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Trash2, 
  Share2, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  MessageSquare,
  Send,
  Sparkles,
  PieChart as PieIcon,
  Zap,
  CheckCircle2,
  Clock,
  Target,
  Download
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie
} from 'recharts';
import { ReportData, ChatMessage } from '../types';
import { chatAboutReport } from '../services/geminiService';

const COLORS = ['#4F46E5', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

interface ReportDetailProps {
  reports: ReportData[];
  removeReport: (id: string) => void;
}

const ReportDetail: React.FC<ReportDetailProps> = ({ reports, removeReport }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const report = reports.find(r => r.id === id);
  
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  if (!report) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Relatório não localizado</h2>
        <Link to="/" className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-sm font-bold">Voltar</Link>
      </div>
    );
  }

  const handleDelete = () => {
    if (window.confirm('Excluir este relatório permanentemente?')) {
      removeReport(report.id);
      navigate('/');
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isTyping) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    try {
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      const response = await chatAboutReport(report, input, history);
      const assistantMsg: ChatMessage = { id: (Date.now() + 1).toString(), role: 'assistant', content: response, timestamp: Date.now() };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) { console.error(err); } finally { setIsTyping(false); }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-12">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4">
          <Link 
            to="/" 
            className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">{report.title}</h1>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-2 mt-0.5">
              <Clock className="w-3 h-3" /> {report.date} • Analista de relatório
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2.5 text-slate-500 hover:text-indigo-600 bg-slate-50 hover:bg-indigo-50 rounded-xl transition-all shadow-sm">
            <Download className="w-4 h-4" />
          </button>
          <button 
            onClick={handleDelete}
            className="p-2.5 text-rose-500 hover:text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-all shadow-sm"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <div className="xl:col-span-8 space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {report.kpis.map((kpi, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group">
                <div className={`absolute top-0 left-0 w-1 h-full ${
                  kpi.trend === 'up' ? 'bg-emerald-500' : kpi.trend === 'down' ? 'bg-rose-500' : 'bg-amber-500'
                }`} />
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{kpi.label}</p>
                <div className="flex items-baseline justify-between">
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">{kpi.value}</h3>
                  <div className={`text-[10px] font-bold uppercase ${
                    kpi.trend === 'up' ? 'text-emerald-600' : kpi.trend === 'down' ? 'text-rose-600' : 'text-amber-600'
                  }`}>
                    {kpi.trend}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-6 flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-600" /> Síntese Operacional
            </h2>
            <p className="text-slate-600 leading-relaxed font-medium">
              {report.summary}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Execução por Segmento</p>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={report.chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} />
                    <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                    <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={30}>
                      {report.chartData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Mix de Origem</p>
              <div className="h-64 relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={report.distributionData}
                      cx="50%" cy="50%"
                      innerRadius={50} outerRadius={80}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {report.distributionData?.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{borderRadius: '12px'}} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-auto grid grid-cols-2 gap-2">
                {report.distributionData?.map((entry, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[index % COLORS.length]}} />
                    <span className="text-[10px] font-bold text-slate-500 truncate">{entry.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#0F172A] p-8 rounded-2xl text-white shadow-xl shadow-indigo-900/10">
              <h3 className="text-sm font-bold mb-6 flex items-center gap-2 text-indigo-400 uppercase tracking-widest">
                <Sparkles className="w-4 h-4" /> Insights de IA
              </h3>
              <div className="space-y-4">
                {report.insights.map((insight, idx) => (
                  <div key={idx} className="flex gap-3 items-start">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                    <p className="text-slate-400 text-xs font-medium leading-relaxed">{insight}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="text-sm font-bold text-slate-900 mb-6 flex items-center gap-2 uppercase tracking-widest">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Recomendações
              </h3>
              <div className="space-y-4">
                {report.recommendations.map((rec, idx) => (
                  <div key={idx} className="flex gap-4 group">
                    <span className="text-xs font-black text-slate-300 group-hover:text-indigo-600 transition-colors">{idx + 1}.</span>
                    <p className="text-slate-600 text-xs font-bold leading-relaxed">{rec}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="xl:col-span-4 h-full">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[calc(100vh-10rem)] sticky top-24 overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
              <div className="bg-indigo-600 p-2 rounded-lg text-white">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Analista Onet</h3>
                <p className="text-[10px] text-emerald-500 font-bold uppercase">Online</p>
              </div>
            </div>

            <div ref={scrollRef} className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50/20 scrollbar-hide">
              {messages.length === 0 && (
                <div className="text-center py-8">
                  <div className="bg-white w-10 h-10 rounded-full flex items-center justify-center mx-auto shadow-sm mb-3">
                    <Sparkles className="w-5 h-5 text-indigo-400" />
                  </div>
                  <p className="text-xs font-bold text-slate-400 leading-relaxed px-4">
                    Questione sobre picos de volume, causas de impedimento ou performance por posto.
                  </p>
                </div>
              )}

              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-xs font-semibold leading-relaxed shadow-sm ${
                    msg.role === 'user' 
                      ? 'bg-indigo-600 text-white' 
                      : 'bg-white text-slate-700 border border-slate-200'
                  }`}>
                    {msg.content}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-100 px-4 py-2 rounded-xl shadow-sm flex items-center gap-1.5">
                    <div className="w-1 h-1 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-1 h-1 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-1 h-1 bg-indigo-400 rounded-full animate-bounce" />
                  </div>
                </div>
              )}
            </div>

            <div className="p-5 border-t border-slate-100">
              <div className="relative">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Mensagem..."
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl py-3 pl-4 pr-12 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-600 outline-none transition-all text-xs font-bold"
                />
                <button 
                  onClick={handleSendMessage}
                  disabled={!input.trim() || isTyping}
                  className="absolute right-2 top-2 p-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-slate-200 transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportDetail;
