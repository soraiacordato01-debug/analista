
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FilePlus, 
  History, 
  Settings, 
  FileText,
  Activity,
  Bell
} from 'lucide-react';
import { ReportData } from './types';
import Dashboard from './components/Dashboard';
import NewAnalysis from './components/NewAnalysis';
import ReportDetail from './components/ReportDetail';

const Sidebar = () => {
  const location = useLocation();
  const menuItems = [
    { icon: LayoutDashboard, label: 'Painel Geral', path: '/' },
    { icon: FilePlus, label: 'Nova Análise', path: '/new' },
    { icon: History, label: 'Histórico', path: '/history' },
  ];

  return (
    <div className="w-64 bg-[#0F172A] text-white min-h-screen flex flex-col fixed left-0 top-0 z-50 border-r border-slate-800">
      <div className="p-6 mb-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">OpenAI</h1>
            <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Operações</p>
          </div>
        </div>
        <div className="h-px bg-slate-800 w-full mt-4" />
      </div>
      
      <nav className="flex-1 px-4 space-y-1">
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                isActive 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20' 
                  : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
              }`}
            >
              <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
              <span className="text-sm font-semibold">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 mt-auto">
        <div className="bg-slate-800/30 rounded-2xl p-4 mb-4 border border-slate-700/50">
           <p className="text-xs font-bold text-slate-300">Onet Brasil</p>
           <p className="text-[10px] text-indigo-400 mt-1 font-semibold uppercase tracking-tight">Analista de relatório</p>
        </div>
        <button className="flex items-center gap-3 px-4 py-3 w-full text-slate-500 hover:text-slate-300 rounded-xl transition-all text-sm font-medium">
          <Settings className="w-5 h-5" />
          Ajustes
        </button>
      </div>
    </div>
  );
};

const TopBar = () => {
  return (
    <header className="h-16 border-b border-slate-200 bg-white sticky top-0 z-40 flex items-center justify-between px-8 ml-64">
      <div className="flex items-center gap-2">
        <span className="text-slate-400 text-sm font-medium">Onet /</span>
        <span className="text-slate-900 text-sm font-bold">Workspace Interno</span>
      </div>
      <div className="flex items-center gap-6">
        <button className="text-slate-400 hover:text-indigo-600 transition-colors relative">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
        </button>
        <div className="h-8 w-px bg-slate-200" />
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-slate-900">Operador Onet</p>
            <p className="text-[10px] text-slate-400 font-medium">Analista de relatório</p>
          </div>
          <div className="w-9 h-9 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center font-bold text-sm">
            ON
          </div>
        </div>
      </div>
    </header>
  );
};

const App: React.FC = () => {
  const [reports, setReports] = useState<ReportData[]>(() => {
    const saved = localStorage.getItem('reports');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('reports', JSON.stringify(reports));
  }, [reports]);

  const addReport = (report: ReportData) => {
    setReports(prev => [report, ...prev]);
  };

  const removeReport = (id: string) => {
    setReports(prev => prev.filter(r => r.id !== id));
  };

  const loadSampleData = () => {
    const sampleReport: ReportData = {
      id: "demo-onet",
      title: "Consolidado Operacional Mensal",
      date: new Date().toLocaleDateString(),
      summary: "Relatório gerado para análise interna de desempenho. Foco em correlação entre origens de chamados e cumprimento de métricas de SLA.",
      kpis: [
        { label: "Cumprimento Plano", value: "94.2%", trend: "up", color: "emerald" },
        { label: "SLA Médio", value: "12 min", trend: "neutral", color: "amber" },
        { label: "Retrabalho", value: "2.1%", trend: "down", color: "rose" }
      ],
      chartData: [
        { name: "Semana 1", value: 88 },
        { name: "Semana 2", value: 92 },
        { name: "Semana 3", value: 95 },
        { name: "Semana 4", value: 91 }
      ],
      distributionData: [
        { name: "Programação", value: 70 },
        { name: "Solicitado", value: 30 }
      ],
      insights: ["Volume de chamados estável no período.", "Impedimentos por acesso restrito em queda constante."],
      recommendations: ["Manter escala operacional atual.", "Reforçar treinamento de novos ingressos."],
      rawText: "Dados Operacionais Onet Brasil"
    };
    addReport(sampleReport);
  };

  return (
    <HashRouter>
      <div className="flex min-h-screen bg-[#F8FAFC]">
        <Sidebar />
        <div className="flex-1">
          <TopBar />
          <main className="ml-64 p-8">
            <Routes>
              <Route path="/" element={<Dashboard reports={reports} onLoadSample={loadSampleData} />} />
              <Route path="/new" element={<NewAnalysis onAnalysisComplete={addReport} />} />
              <Route path="/report/:id" element={<ReportDetail reports={reports} removeReport={removeReport} />} />
              <Route path="/history" element={<Dashboard reports={reports} title="Arquivo de Relatórios" />} />
            </Routes>
          </main>
        </div>
      </div>
    </HashRouter>
  );
};

export default App;
