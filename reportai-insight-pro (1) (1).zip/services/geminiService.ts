
import { GoogleGenAI, Type } from "@google/genai";
import { ReportData } from "../types";

// Note: process.env.API_KEY is pre-configured
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "Professional title for the HCFMUSP operational report." },
    summary: { type: Type.STRING, description: "Technical executive summary focusing on correlations between volume and performance." },
    kpis: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING, description: "Metric name (e.g., 'Previsto vs Realizado')." },
          value: { type: Type.STRING, description: "Formatted value (e.g., '92.5%')." },
          trend: { type: Type.STRING, description: "'up', 'down', or 'neutral'." },
          color: { type: Type.STRING, description: "'emerald', 'rose', or 'amber'." }
        },
        required: ["label", "value", "trend", "color"]
      }
    },
    chartData: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          value: { type: Type.NUMBER }
        },
        required: ["name", "value"]
      }
    },
    distributionData: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Operational Origin (QR Code, CCO, IoT, etc.)" },
          value: { type: Type.NUMBER }
        },
        required: ["name", "value"]
      }
    },
    insights: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "Deep technical correlations (e.g., how 'Ambiente Trancado' impacts SLA in specific wards)."
    },
    recommendations: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "Strategic actions based on the analysis of impediments and origins."
    }
  },
  required: ["title", "summary", "kpis", "chartData", "distributionData", "insights", "recommendations"]
};

export async function analyzeReport(input: string, isImage: boolean = false): Promise<ReportData> {
  const model = 'gemini-3-pro-preview';
  
  const systemInstruction = `Atue como um Especialista em Análise Operacional da Onet Brasil no projeto HCFMUSP. Sua função é correlacionar KPIs e encontrar a narrativa por trás dos números.

BASE DE DADOS - CAMPOS DISPONÍVEIS:
- Id (Atividade), Nome Popular/Técnico (Sala), Posto de Trabalho (Agrupador por funcionário).
- Horários: Data, Das/Até (Previsto), Início/Término (Real), Duração.
- Performance: SLA (Variação entre previsto e realizado), Status (Planejado, Aguardando, Em andamento, Impedido, Cancelado, Reagendado).
- Impedimentos: Tipo de Impedimento (Causa da não execução).
- Origem do Chamado: Programação (Mensal), Servente Onet (Iniciativa própria/Direto), Landing Page – Cliente (QR Code), IoT (Sensores de fluxo), CCO (Telefone/Ramal).
- Recursos: Funcionário Emprestado, Fotos, Classificação (Ambiente), Esforço (HH), Qtde Ajudantes.

SUA LÓGICA DE ANÁLISE:
1. Previsto vs Realizado: Analise se a Programação mensal está sendo negligenciada devido ao excesso de chamados via QR Code ou CCO.
2. Solicitado vs Realizado: Avalie a eficiência do atendimento avulso.
3. Tempo de Resposta (SLA): Correlacione o tempo com a Origem (Ex: CCO demora mais que QR Code?).
4. Impedimentos: Identifique padrões (Ex: 'Ambiente Trancado' é recorrente em qual Posto de Trabalho?).

TOM DE VOZ: Direto, profissional e técnico.`;

  const prompt = isImage 
    ? "Analise este relatório de limpeza do HCFMUSP. Correlacione as origens de chamados com os índices de impedimento e SLA."
    : `Analise os seguintes dados operacionais da Onet Brasil (HCFMUSP). Procure correlações entre Status, Origem e SLA:\n\n${input}`;

  const response = await ai.models.generateContent({
    model,
    contents: isImage 
      ? { parts: [{ inlineData: { mimeType: 'image/jpeg', data: input } }, { text: prompt }] }
      : { parts: [{ text: prompt }] },
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: ANALYSIS_SCHEMA,
    }
  });

  const responseText = response.text;
  if (!responseText) throw new Error("Falha na geração da análise.");

  const parsed = JSON.parse(responseText);
  return {
    ...parsed,
    id: Math.random().toString(36).substr(2, 9),
    date: new Date().toLocaleDateString(),
    rawText: isImage ? "Extraído de Imagem" : input
  };
}

export async function chatAboutReport(report: ReportData, message: string, history: {role: string, content: string}[]): Promise<string> {
  const chatAi = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  
  const chat = chatAi.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: `Você é o Especialista de Operações da Onet Brasil (HCFMUSP). 
      Responda dúvidas técnicas sobre o relatório: ${report.title}. 
      Contexto: ${report.summary}. 
      Métricas: ${JSON.stringify(report.kpis)}.
      Insights: ${report.insights.join('; ')}.
      Sempre cite a relação entre Origem (QR Code, CCO, Programação) e Impedimentos quando pertinente.`
    },
    history: history.map(h => ({
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: h.content }]
    }))
  });

  const response = await chat.sendMessage({ message });
  return response.text || "Erro na resposta do analista.";
}
