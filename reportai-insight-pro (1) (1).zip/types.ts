
export interface ReportData {
  id: string;
  title: string;
  date: string;
  summary: string;
  kpis: KPI[];
  chartData: ChartPoint[];
  distributionData?: ChartPoint[]; // Used for Pie charts (e.g., Origins distribution)
  insights: string[];
  recommendations: string[];
  rawText?: string;
}

export interface KPI {
  label: string;
  value: string;
  trend: 'up' | 'down' | 'neutral';
  color: string;
  icon?: string; // Optional icon name from lucide
}

export interface ChartPoint {
  name: string;
  value: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}
