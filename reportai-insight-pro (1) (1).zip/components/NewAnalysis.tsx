
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Type as TypeIcon, Send, Loader2, X, FileText, ImageIcon, FileSearch } from 'lucide-react';
import { analyzeReport } from '../services/geminiService';
import { ReportData } from '../types';

interface NewAnalysisProps {
  onAnalysisComplete: (report: ReportData) => void;
}

const NewAnalysis: React.FC<NewAnalysisProps> = ({ onAnalysisComplete }) => {
  const [mode, setMode] = useState<'text' | 'file'>('text');
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileData, setFileData] = useState<{ base64: string; name: string } | null>(null);
  const navigate = useNavigate();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      setFileData({ base64, name: file.name });
    };
    reader.readAsDataURL(file);
  };

  const handleStartAnalysis = async () => {
    if (mode === 'text' && !inputText.trim()) return;
    if (mode === 'file' && !fileData) return;

    setIsLoading(true);
    setError(null);
    try {
      const result = await analyzeReport(
        mode === 'text' ? inputText : fileData!.base64,
        mode === 'file'
      );
      onAnalysisComplete(result);
      navigate(`/report/${result.id}`);
    } catch (err: any) {
      console.error(err);
      setError('Falha na conexão com o servidor de análise. Tente dados mais curtos.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">Configurar Nova Análise</h1>
        <p className="text-sm text-slate-500 font-medium mt-1">Analista de relatório</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex border-b border-slate-100 bg-slate-50/50">
          <button 
            onClick={() => setMode('text')}
            className={`flex-1 flex items-center justify-center gap-2 py-4 text-sm font-bold transition-all ${
              mode === 'text' 
                ? 'bg-white text-indigo-600 border-b-2 border-indigo-600 shadow-sm' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <TypeIcon className="w-4 h-4" />
            Entrada Direta
          </button>
          <button 
            onClick={() => setMode('file')}
            className={`flex-1 flex items-center justify-center gap-2 py-4 text-sm font-bold transition-all ${
              mode === 'file' 
                ? 'bg-white text-indigo-600 border-b-2 border-indigo-600 shadow-sm' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Upload className="w-4 h-4" />
            Anexo de Documento
          </button>
        </div>

        <div className="p-8">
          {error && (
            <div className="mb-6 p-4 bg-rose-50 border border-rose-100 text-rose-600 rounded-xl flex items-center gap-3 text-sm font-bold">
              <X className="w-4 h-4" />
              {error}
            </div>
          )}

          {mode === 'text' ? (
            <div className="space-y-4">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest">Base de Dados (JSON / CSV / Texto)</label>
              <textarea 
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Cole aqui os logs ou dados brutos do sistema Onet..."
                className="w-full h-80 p-6 rounded-xl border border-slate-200 bg-slate-50/30 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 outline-none transition-all resize-none text-slate-700 font-mono text-xs leading-relaxed"
              />
            </div>
          ) : (
            <div className="space-y-6">
              {!fileData ? (
                <div className="relative group">
                  <input 
                    type="file" 
                    onChange={handleFileUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    accept=".jpg,.jpeg,.png,.webp,.pdf,.xlsx,.csv"
                  />
                  <div className="border-2 border-dashed border-slate-200 rounded-2xl p-16 flex flex-col items-center justify-center transition-all group-hover:border-indigo-400 group-hover:bg-indigo-50/20">
                    <div className="bg-slate-100 p-4 rounded-xl mb-4 group-hover:scale-110 transition-transform text-slate-400 group-hover:text-indigo-600">
                      <Upload className="w-8 h-8" />
                    </div>
                    <p className="text-sm font-bold text-slate-700">Selecione o arquivo da operação</p>
                    <p className="text-[10px] text-slate-400 mt-2 uppercase font-black tracking-widest">Excel, PDF ou Imagem</p>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="bg-indigo-600 p-3 rounded-xl text-white">
                      <FileSearch className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">{fileData.name}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Arquivo carregado</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setFileData(null)}
                    className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
          )}

          <div className="mt-8 flex justify-end">
            <button 
              onClick={handleStartAnalysis}
              disabled={isLoading || (mode === 'text' ? !inputText.trim() : !fileData)}
              className="bg-[#0F172A] text-white px-10 py-3 rounded-xl font-bold hover:bg-slate-800 disabled:bg-slate-200 disabled:cursor-not-allowed transition-all flex items-center gap-2 shadow-lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Gerar Relatório Técnico
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewAnalysis;
