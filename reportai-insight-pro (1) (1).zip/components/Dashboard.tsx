
import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Calendar, ChevronRight, Inbox, Sparkles, LayoutGrid, List } from 'lucide-react';
import { ReportData } from '../types';

interface DashboardProps {
  reports: ReportData[];
  title?: string;
  onLoadSample?: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ reports, title = "Dashboard Principal", onLoadSample }) => {
  if (reports.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center max-w-2xl mx-auto">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 mb-6 w-full">
          <div className="bg-indigo-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 text-indigo-600">
            <Inbox className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Sem análises registradas</h2>
          <p className="text-slate-500 mb-8 font-medium">Analista de relatório</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              to="/new" 
              className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-md flex items-center justify-center gap-2"
            >
              Nova Análise
            </Link>
            {onLoadSample && (
              <button 
                onClick={onLoadSample}
                className="bg-white text-slate-700 border border-slate-200 px-8 py-3 rounded-xl font-bold hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
              >
                Gerar Exemplo
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in duration-500 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Analista de relatório</p>
        </div>
        <Link 
          to="/new" 
          className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-md flex items-center gap-2 text-sm"
        >
          <Sparkles className="w-4 h-4" />
          Nova Análise
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report) => (
          <Link 
            key={report.id} 
            to={`/report/${report.id}`}
            className="group bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-xl hover:shadow-slate-200/50 hover:border-indigo-200 transition-all duration-300 flex flex-col"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="bg-slate-50 p-3 rounded-xl text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                <FileText className="w-6 h-6" />
              </div>
              <div className="text-[10px] font-bold text-slate-400 bg-slate-50 px-3 py-1 rounded-full group-hover:bg-indigo-50 group-hover:text-indigo-400 transition-colors">
                {report.date}
              </div>
            </div>
            
            <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-indigo-600 transition-colors leading-snug">
              {report.title}
            </h3>
            <p className="text-slate-500 text-xs leading-relaxed line-clamp-2 mb-6">
              {report.summary}
            </p>

            <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
              <div className="flex -space-x-2">
                {report.kpis.slice(0, 3).map((kpi, idx) => (
                  <div 
                    key={idx} 
                    title={kpi.label}
                    className="w-8 h-8 rounded-lg border-2 border-white flex items-center justify-center text-[9px] font-bold text-white shadow-sm"
                    style={{ backgroundColor: kpi.color === 'emerald' ? '#10b981' : kpi.color === 'rose' ? '#f43f5e' : '#f59e0b' }}
                  >
                    {kpi.value.replace('%', '')}
                  </div>
                ))}
              </div>
              <div className="text-indigo-600 text-[10px] font-bold flex items-center gap-1">
                Visualizar <ChevronRight className="w-3 h-3" />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
